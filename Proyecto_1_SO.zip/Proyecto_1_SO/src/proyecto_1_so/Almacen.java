package proyecto_1_so;

public class Almacen extends Thread {

    public volatile int cantidadDeProducto;
    public int productos[];
    public int entrada;
    public int salida;
    public int espacio;
    Interfaz interfaz;

    public Almacen(int cantidadDeProducto, int espacio, Interfaz interfaz) {
        this.cantidadDeProducto = cantidadDeProducto;
        this.espacio = espacio;
        int vector[] = new int[espacio];
        productos = vector;
        this.interfaz = interfaz;
    }

    public synchronized void meterProducto(int cantidad, String tipo) {
        cantidadDeProducto = cantidadDeProducto + cantidad;
        for (int i = 1; i <= cantidad; i++) {
            productos[entrada] = 1;
            entrada = (entrada + 1) % espacio;
        }
        switch (tipo) {
            case "Pata":
                System.out.println("Se agrego " + cantidad + " Pata al Almacen.");
                interfaz.jTextAreaEstado("Se agrego " + cantidad + " Pata al Almacen.\n");
                interfaz.jLabelCantidadDePatas(cantidadDeProducto);
                break;
            case "Tornillo":
                System.out.println("Se agrego " + cantidad + " Tornillo al Almacen.");
                interfaz.jTextAreaEstado("Se agrego " + cantidad + " Tornillo al Almacen.\n");
                interfaz.jLabelCantidadDeTornillos(cantidadDeProducto);
                break;
            case "Tabla":
                System.out.println("Se agrego " + cantidad + " Tabla al Almacen.");
                interfaz.jTextAreaEstado("Se agrego " + cantidad + " Tabla al Almacen.\n");
                interfaz.jLabelCantidadDeTablas(cantidadDeProducto);
                break;
        }
    }

    public synchronized void sacarProducto(int cantidad, String tipo) {
        cantidadDeProducto = cantidadDeProducto - cantidad;
        for (int i = 1; i <= cantidad; i++) {
            productos[salida] = 0;
            salida = (salida + 1) % espacio;
        }
        switch (tipo) {
            case "Pata":
                System.out.println("Se saco " + cantidad + " Pata al Almacen.");
                interfaz.jTextAreaEstado("Se saco " + cantidad + " Pata al Almacen.\n");
                interfaz.jLabelCantidadDePatas(cantidadDeProducto);
                break;
            case "Tornillo":
                System.out.println("Se saco " + cantidad + " Tornillo al Almacen.");
                interfaz.jTextAreaEstado("Se saco " + cantidad + " Tornillo al Almacen.\n");
                interfaz.jLabelCantidadDeTornillos(cantidadDeProducto);
                break;
            case "Tabla":
                System.out.println("Se saco " + cantidad + " Tabla al Almacen.");
                interfaz.jTextAreaEstado("Se saco " + cantidad + " Tabla al Almacen.\n");
                interfaz.jLabelCantidadDeTablas(cantidadDeProducto);
                break;
        }
    }

    public void escritorioFabricado() {
        interfaz.jTextAreaEstado("Se ha creado un escritorio con exito.\n");
        interfaz.agregarEscritorioTerminado();
    }

}
