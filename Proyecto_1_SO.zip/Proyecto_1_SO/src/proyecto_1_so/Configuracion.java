
package proyecto_1_so;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Configuracion {
    public int duracionDelDia;
    public int diasEntreDespachos;
    public int productoresDePatasCantidadInicial;
    public int productoresDePatasCantidadMaxima;
    public int productoresDePatasCapacidadMaximaDelAlmacen;
    public int productoresDeTornillosCantidadInicial;
    public int productoresDeTornillosCantidadMaxima;
    public int productoresDeTornillosCapacidadMaximaDelAlmacen;
    public int productoresDeTablasCantidadInicial;
    public int productoresDeTablasCantidadMaxima;
    public int productoresDeTablasCapacidadMaximaDelAlmacen;
    public int ensambladoresCantidadInicial;
    public int ensambladoresCantidadMaxima;
    
    public Configuracion() {
    }
    
    public Configuracion(int DuracionDelDia, int DiasEntreDespachos, int ProductoresDePatasCantidadInicial, int ProductoresDePatasCantidadMaxima, int ProductoresDePatasCapacidadMaximaDelAlmacen, int ProductoresDeTornillosCantidadInicial, int ProductoresDeTornillosCantidadMaxima, int ProductoresDeTornillosCapacidadMaximaDelAlmacen, int ProductoresDeTablasCantidadInicial, int ProductoresDeTablasCantidadMaxima, int ProductoresDeTablasCapacidadMaximaDelAlmacen, int EnsambladoresCantidadInicial, int EnsambladoresCantidadMaxima) {
        this.duracionDelDia = DuracionDelDia;
        this.diasEntreDespachos = DiasEntreDespachos;
        this.productoresDePatasCantidadInicial = ProductoresDePatasCantidadInicial;
        this.productoresDePatasCantidadMaxima = ProductoresDePatasCantidadMaxima;
        this.productoresDePatasCapacidadMaximaDelAlmacen = ProductoresDePatasCapacidadMaximaDelAlmacen;
        this.productoresDeTornillosCantidadInicial = ProductoresDeTornillosCantidadInicial;
        this.productoresDeTornillosCantidadMaxima = ProductoresDeTornillosCantidadMaxima;
        this.productoresDeTornillosCapacidadMaximaDelAlmacen = ProductoresDeTornillosCapacidadMaximaDelAlmacen;
        this.productoresDeTablasCantidadInicial = ProductoresDeTablasCantidadInicial;
        this.productoresDeTablasCantidadMaxima = ProductoresDeTablasCantidadMaxima;
        this.productoresDeTablasCapacidadMaximaDelAlmacen = ProductoresDeTablasCapacidadMaximaDelAlmacen;
        this.ensambladoresCantidadInicial = EnsambladoresCantidadInicial;
        this.ensambladoresCantidadMaxima = EnsambladoresCantidadMaxima;
    }

    public int getDuracionDelDia() {
        return duracionDelDia;
    }

    public void setDuracionDelDia(int duracionDelDia) {
        this.duracionDelDia = duracionDelDia;
    }

    public int getDiasEntreDespachos() {
        return diasEntreDespachos;
    }

    public void setDiasEntreDespachos(int diasEntreDespachos) {
        this.diasEntreDespachos = diasEntreDespachos;
    }

    public int getProductoresDePatasCantidadInicial() {
        return productoresDePatasCantidadInicial;
    }

    public void setProductoresDePatasCantidadInicial(int productoresDePatasCantidadInicial) {
        this.productoresDePatasCantidadInicial = productoresDePatasCantidadInicial;
    }

    public int getProductoresDePatasCantidadMaxima() {
        return productoresDePatasCantidadMaxima;
    }

    public void setProductoresDePatasCantidadMaxima(int productoresDePatasCantidadMaxima) {
        this.productoresDePatasCantidadMaxima = productoresDePatasCantidadMaxima;
    }

    public int getProductoresDePatasCapacidadMaximaDelAlmacen() {
        return productoresDePatasCapacidadMaximaDelAlmacen;
    }

    public void setProductoresDePatasCapacidadMaximaDelAlmacen(int productoresDePatasCapacidadMaximaDelAlmacen) {
        this.productoresDePatasCapacidadMaximaDelAlmacen = productoresDePatasCapacidadMaximaDelAlmacen;
    }

    public int getProductoresDeTornillosCantidadInicial() {
        return productoresDeTornillosCantidadInicial;
    }

    public void setProductoresDeTornillosCantidadInicial(int productoresDeTornillosCantidadInicial) {
        this.productoresDeTornillosCantidadInicial = productoresDeTornillosCantidadInicial;
    }

    public int getProductoresDeTornillosCantidadMaxima() {
        return productoresDeTornillosCantidadMaxima;
    }

    public void setProductoresDeTornillosCantidadMaxima(int productoresDeTornillosCantidadMaxima) {
        this.productoresDeTornillosCantidadMaxima = productoresDeTornillosCantidadMaxima;
    }

    public int getProductoresDeTornillosCapacidadMaximaDelAlmacen() {
        return productoresDeTornillosCapacidadMaximaDelAlmacen;
    }

    public void setProductoresDeTornillosCapacidadMaximaDelAlmacen(int productoresDeTornillosCapacidadMaximaDelAlmacen) {
        this.productoresDeTornillosCapacidadMaximaDelAlmacen = productoresDeTornillosCapacidadMaximaDelAlmacen;
    }

    public int getProductoresDeTablasCantidadInicial() {
        return productoresDeTablasCantidadInicial;
    }

    public void setProductoresDeTablasCantidadInicial(int productoresDeTablasCantidadInicial) {
        this.productoresDeTablasCantidadInicial = productoresDeTablasCantidadInicial;
    }

    public int getProductoresDeTablasCantidadMaxima() {
        return productoresDeTablasCantidadMaxima;
    }

    public void setProductoresDeTablasCantidadMaxima(int productoresDeTablasCantidadMaxima) {
        this.productoresDeTablasCantidadMaxima = productoresDeTablasCantidadMaxima;
    }

    public int getProductoresDeTablasCapacidadMaximaDelAlmacen() {
        return productoresDeTablasCapacidadMaximaDelAlmacen;
    }

    public void setProductoresDeTablasCapacidadMaximaDelAlmacen(int productoresDeTablasCapacidadMaximaDelAlmacen) {
        this.productoresDeTablasCapacidadMaximaDelAlmacen = productoresDeTablasCapacidadMaximaDelAlmacen;
    }

    public int getEnsambladoresCantidadInicial() {
        return ensambladoresCantidadInicial;
    }

    public void setEnsambladoresCantidadInicial(int ensambladoresCantidadInicial) {
        this.ensambladoresCantidadInicial = ensambladoresCantidadInicial;
    }

    public int getEnsambladoresCantidadMaxima() {
        return ensambladoresCantidadMaxima;
    }

    public void setEnsambladoresCantidadMaxima(int ensambladoresCantidadMaxima) {
        this.ensambladoresCantidadMaxima = ensambladoresCantidadMaxima;
    }

    public Configuracion cargarConfiguracion() {
        // Leer el archivo JSON
        String json = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader("src/proyecto_1_so/Configuracion.json"));
            String linea;
            while ((linea = br.readLine()) != null) {
                json += linea;
            }
            br.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Utilizando la libreria Gson
        Gson gson = new Gson();
        Configuracion config = new Configuracion();
        try {
            config = gson.fromJson(json, Configuracion.class);
            System.out.println(config);
            return config;
        } catch (JsonParseException e) {
            System.out.println("Error!");
        }
        return config;
    }
    
}


