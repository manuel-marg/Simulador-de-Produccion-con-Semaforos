package proyecto_1_so;

import java.awt.Toolkit;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Ensamblador extends Thread {

    public Semaphore productorPatas;
    public Semaphore consumidorPatas;
    public Semaphore actividadPatas;
    public Semaphore productorTornillos;
    public Semaphore consumidorTornillos;
    public Semaphore actividadTornillos;
    public Semaphore productorTablas;
    public Semaphore consumidorTablas;
    public Semaphore actividadTablas;
    public Almacen almacenPatas;
    public Almacen almacenTornillos;
    public Almacen almacenTablas;
    public String nombre;
    public boolean continuar;

    public Ensamblador(Semaphore productorPatas, Semaphore consumidorPatas, Semaphore actividadPatas, Semaphore productorTornillos, Semaphore consumidorTornillos, Semaphore actividadTornillos, Semaphore productorTablas, Semaphore consumidorTablas, Semaphore actividadTablas, Almacen almacenPatas, Almacen almacenTornillos, Almacen almacenTablas, String nombre, boolean continuar) {
        this.productorPatas = productorPatas;
        this.consumidorPatas = consumidorPatas;
        this.actividadPatas = actividadPatas;
        this.productorTornillos = productorTornillos;
        this.consumidorTornillos = consumidorTornillos;
        this.actividadTornillos = actividadTornillos;
        this.productorTablas = productorTablas;
        this.consumidorTablas = consumidorTablas;
        this.actividadTablas = actividadTablas;
        this.almacenPatas = almacenPatas;
        this.almacenTornillos = almacenTornillos;
        this.almacenTablas = almacenTablas;
        this.nombre = nombre;
        this.continuar = continuar;
    }

    @Override
    public void run() {
        while (!this.continuar) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(Ensamblador.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        try {
            int duracion = (1000 * duracionDelDia()) * 2; //  Le toma 2 días producir un escritorio
            Thread.sleep(duracion);

            this.consumidorPatas.acquire(4);
            this.consumidorTornillos.acquire(40);
            this.consumidorTablas.acquire(1);

            this.actividadPatas.acquire();
            this.actividadTornillos.acquire();
            this.actividadTablas.acquire();

            this.almacenPatas.sacarProducto(4, "Pata");
            this.almacenTornillos.sacarProducto(40, "Tornillo");
            this.almacenTablas.sacarProducto(1, "Tabla");

            System.out.println("\nSe fabrico un escritorio\n");
            Toolkit.getDefaultToolkit().beep();
            this.almacenPatas.escritorioFabricado();

            this.actividadTablas.release();
            this.actividadTornillos.release();
            this.actividadPatas.release();

            this.productorTablas.release(1);
            this.productorTornillos.release(40);
            this.productorPatas.release(4);
        } catch (InterruptedException ex) {
            Logger.getLogger(Ensamblador.class.getName()).log(Level.SEVERE, null, ex);
        }

        run();

    }

    // Retorna la duracion de los dias en segundos
    public int duracionDelDia() {
        int duracionDelDia = Interfaz.duracionDelDia;
        return duracionDelDia;
    }

}
