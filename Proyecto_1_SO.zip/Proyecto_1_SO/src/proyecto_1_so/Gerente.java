package proyecto_1_so;

import java.awt.Toolkit;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Gerente extends Thread {

    public Semaphore actividad;
    boolean durmiendo;
    boolean continuar;
    Interfaz interfaz;

    public Gerente(Semaphore actividad, boolean durmiendo, boolean continuar, Interfaz interfaz) {
        this.actividad = actividad;
        this.durmiendo = durmiendo;
        this.continuar = continuar;
        this.interfaz = interfaz;
    }

    @Override
    public void run() {

        while (!this.continuar) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(Ensamblador.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        try {
            this.actividad.acquire();
            this.durmiendo = false;
            this.interfaz.jLabelGerente("Verificando cuantos días faltan");
            System.out.println("Verificando cuantos días faltan");
            if (this.interfaz.diasRestantes == 0) {
                this.interfaz.jLabelCantidadDeEscritorios(0);
                this.interfaz.diasRestantes = this.interfaz.config.diasEntreDespachos;
                this.interfaz.actualizarInterfaz();
            }
            this.durmiendo = true;
            this.interfaz.jLabelGerente("Dormido");
            System.out.println("Gerente se fue a dormir por 8 horas");
            this.actividad.release();
            Thread.sleep((8 * (duracionDelDia() * 1000)) / 24); // Se va a dormir 8 horas
        } catch (InterruptedException ex) {
            Logger.getLogger(Gerente.class.getName()).log(Level.SEVERE, null, ex);
        }
        run();
    }

    // Retorna la duracion del dia en segundos
    public int duracionDelDia() {
        int duracionDelDia = Interfaz.duracionDelDia;
        return duracionDelDia;
    }
}
