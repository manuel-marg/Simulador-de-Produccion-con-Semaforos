package proyecto_1_so;

import java.awt.Toolkit;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Jefe extends Thread {

    public Semaphore actividad;
    boolean durmiendo;
    boolean continuar;
    Interfaz interfaz;

    public Jefe(Semaphore actividad, boolean durmiendo, boolean continuar, Interfaz interfaz) {
        this.actividad = actividad;
        this.durmiendo = durmiendo;
        this.continuar = continuar;
        this.interfaz = interfaz;
    }

    @Override
    public void run() {
        while (!this.continuar) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(Ensamblador.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        try {
            Thread.sleep((16 * (duracionDelDia() * 1000)) / 24); // Resto del dia
            this.actividad.acquire();
            this.durmiendo = false;
            this.interfaz.jLabelJefe("Registrando el paso de los días");
            System.out.println("Jefe empieza a cambiar el contador");
            Thread.sleep((8 * (duracionDelDia() * 1000)) / 24); // Le toma 8 horas
            this.interfaz.diasRestantes--;
            this.interfaz.jLabelDiasParaLaEntrega();
            this.durmiendo = true;
            this.interfaz.jLabelJefe("Dormido");
            System.out.println("Jefe se fue a dormir");
            this.actividad.release();
        } catch (InterruptedException ex) {
            Logger.getLogger(Jefe.class.getName()).log(Level.SEVERE, null, ex);
        }
        run();

    }

    // Retorna la duracion del dia en segundos
    public int duracionDelDia() {
        int duracionDelDia = Interfaz.duracionDelDia;
        return duracionDelDia;
    }
}
