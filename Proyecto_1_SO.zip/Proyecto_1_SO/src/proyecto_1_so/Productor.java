package proyecto_1_so;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Productor extends Thread {

    public Semaphore productor;
    public Semaphore consumidor;
    public Semaphore actividad;
    public Almacen almacen;
    public String nombre;
    public String tipo;
    public boolean continuar;

    public Productor(Semaphore productor, Semaphore consumidor, Semaphore actividad, Almacen almacen, String nombre, String tipo, boolean continuar) {
        this.productor = productor;
        this.consumidor = consumidor;
        this.actividad = actividad;
        this.almacen = almacen;
        this.nombre = nombre;
        this.tipo = tipo;
        this.continuar = continuar;
    }

    @Override
    public void run() {

        while (!this.continuar) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(Productor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        // Duracion de la creacion del producto
        int duracion;

        try {
            // Dependiendo del tipo va caer el caso correspondiente para que corresponda el tiempo correcto
            switch (this.tipo) {
                case "Pata":
                    this.productor.acquire();
                    this.actividad.acquire();
                    this.almacen.meterProducto(1, tipo); // Guardamos el producto en el Almacen
                    this.actividad.release();
                    duracion = (1000 * duracionDelDia()) / 2; //  Puede hacer 2 patas por día
                    Thread.sleep(duracion);
                    this.consumidor.release();
                    break;
                case "Tornillo":
                    this.productor.acquire();
                    this.actividad.acquire();
                    this.almacen.meterProducto(1, tipo); // Guardamos el producto en el Almacen
                    this.actividad.release();
                    duracion = (1000 * duracionDelDia()) / 30; // Puede hacer 30 tornillos por día 
                    Thread.sleep(duracion);
                    this.consumidor.release();
                    break;
                case "Tabla":
                    this.productor.acquire();
                    this.actividad.acquire();
                    almacen.meterProducto(1, tipo); // Guardamos el producto en el Almacen
                    this.actividad.release();
                    duracion = (1000 * duracionDelDia()) * 3; // Le toma 3 días hacer una tabla
                    Thread.sleep(duracion);
                    this.consumidor.release();
                    break;
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Productor.class.getName()).log(Level.SEVERE, null, ex);
        }
        run();
    }

    public void activar() {
        this.continuar = true;
    }

    public void desactivar() {
        this.continuar = false;
    }

    // Retorna la duracion del dia en segundos
    public int duracionDelDia() {
        int duracionDelDia = Interfaz.duracionDelDia;
        return duracionDelDia;
    }

}
