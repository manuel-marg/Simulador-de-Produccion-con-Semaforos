package proyecto_1_so;

import java.util.concurrent.Semaphore;

public class Proyecto_1_SO {

    public static void main(String[] args) {
        // Cargando la configuracion
        Configuracion config = new Configuracion();
        config = config.cargarConfiguracion();

        // Ejecutar el JFrame
        Interfaz interfaz = new Interfaz();
        interfaz.setVisible(true);

        // Semaforos de Patas
        Semaphore productorPatas = new Semaphore(config.productoresDePatasCapacidadMaximaDelAlmacen);
        Semaphore comsumidorPatas = new Semaphore(0);
        Semaphore actividadPatas = new Semaphore(1);
        // Almacen de Patas
        Almacen almacenPatas = new Almacen(0, config.productoresDePatasCapacidadMaximaDelAlmacen, interfaz);

        // Semaforos de Tornillos
        Semaphore productorTornillos = new Semaphore(config.productoresDeTornillosCapacidadMaximaDelAlmacen);
        Semaphore comsumidorTornillos = new Semaphore(0);
        Semaphore actividadTornillos = new Semaphore(1);
        // Almacen de Tornillos
        Almacen almacenTornillos = new Almacen(0, config.productoresDeTornillosCapacidadMaximaDelAlmacen, interfaz);

        // Semaforos de Tablas
        Semaphore productorTablas = new Semaphore(config.productoresDeTablasCapacidadMaximaDelAlmacen);
        Semaphore comsumidorTablas = new Semaphore(0);
        Semaphore actividadTablas = new Semaphore(1);
        // Almacen de Tablas
        Almacen almacenTablas = new Almacen(0, config.productoresDeTablasCapacidadMaximaDelAlmacen, interfaz);

        // Productores de Patas
        Productor[] vectorDeProductoresDePatas = new Productor[config.productoresDePatasCantidadMaxima];
        for (int i = 0; i < config.productoresDePatasCantidadMaxima; i++) {
            vectorDeProductoresDePatas[i] = new Productor(productorPatas, comsumidorPatas, actividadPatas, almacenPatas, "produtorDePatas" + i, "Pata", false);
            System.out.println("vectorDeProductorDePatas[" + i + "] Se crea el productor de Patas.");
            // Inicia los productores inicales segun el archivo de config
            if (i <= config.productoresDePatasCantidadInicial - 1) {
                System.out.println("vectorDeProductorDePatas[" + i + "] Se inicia el productor.");
                vectorDeProductoresDePatas[i].continuar = true;
                vectorDeProductoresDePatas[i].start();
            }
        }

        // Productores de Tornillos
        Productor[] vectorDeProductoresDeTornillos = new Productor[config.productoresDeTornillosCantidadMaxima];
        for (int i = 0; i < config.productoresDeTornillosCantidadMaxima; i++) {
            vectorDeProductoresDeTornillos[i] = new Productor(productorTornillos, comsumidorTornillos, actividadTornillos, almacenTornillos, "produtorDeTornillos" + i, "Tornillo", false);
            System.out.println("vectorDeProductorDeTornillos[" + i + "] Se crea el productor de Tornillos.");
            // Inicia los productores inicales segun el archivo de config
            if (i <= config.productoresDeTornillosCantidadInicial - 1) {
                System.out.println("vectorDeProductorDeTornillos[" + i + "] Se inicia el productor.");
                vectorDeProductoresDeTornillos[i].continuar = true;
                vectorDeProductoresDeTornillos[i].start();
            }
        }

        // Productores de Tablas
        Productor[] vectorDeProductoresDeTablas = new Productor[config.productoresDeTablasCantidadMaxima];
        for (int i = 0; i < config.productoresDeTablasCantidadMaxima; i++) {
            vectorDeProductoresDeTablas[i] = new Productor(productorTablas, comsumidorTablas, actividadTablas, almacenTablas, "produtorDeTablas" + i, "Tabla", false);
            System.out.println("vectorDeProductorDeTablas[" + i + "] Se crea el productor de Tablas.");
            // Inicia los productores inicales segun el archivo de config
            if (i <= config.productoresDeTablasCantidadInicial - 1) {
                System.out.println("vectorDeProductorDeTablas[" + i + "] Se inicia el productor.");
                vectorDeProductoresDeTablas[i].continuar = true;
                vectorDeProductoresDeTablas[i].start();
            }
        }

        // Emsamblador de escritorios
        Ensamblador vectorDeEnsambladores[] = new Ensamblador[config.ensambladoresCantidadMaxima];
        for (int i = 0; i < config.ensambladoresCantidadMaxima; i++) {
            vectorDeEnsambladores[i] = new Ensamblador(productorPatas, comsumidorPatas, actividadPatas, productorTornillos, comsumidorTornillos, actividadTornillos, productorTablas, comsumidorTablas, actividadTablas, almacenPatas, almacenTornillos, almacenTablas, "ensamblador" + i, false);
            System.out.println("vectorDeEnsambladores[" + i + "] Se crea el ensamblador.");
            // Inicia los Emsamblador inicales segun el archivo de config
            if (i <= config.ensambladoresCantidadInicial - 1) {
                System.out.println("vectorDeEnsambladores[" + i + "] Se inicia el ensamblador.");
                vectorDeEnsambladores[i].continuar = true;
                vectorDeEnsambladores[i].start();
            }
        }

        // Cargar valor de Dias restantes para la entrega
        interfaz.diasRestantes = config.diasEntreDespachos;

        // Pasar la configuracion
        interfaz.config = config;

        // Pasar la duracion del dia a la variable en la Interfaz
        interfaz.duracionDelDia = config.duracionDelDia;

        // Semaforo para el Jefe y el Gerente
        Semaphore actividadJefeGerente = new Semaphore(1);

        // Jefe de la empresa
        Jefe jefe = new Jefe(actividadJefeGerente, true, true, interfaz);
        jefe.start();

        // Genrente de la empresa
        Gerente gerente = new Gerente(actividadJefeGerente, true, true, interfaz);
        gerente.start();

        // Paso los vectores de los productores a interfaz
        interfaz.setVectorDeProductoresDePatas(vectorDeProductoresDePatas);
        interfaz.setVectorDeProductoresDeTornillos(vectorDeProductoresDeTornillos);
        interfaz.setVectorDeProductoresDeTablas(vectorDeProductoresDeTablas);
        // Paso el vector de los ensambladores
        interfaz.setVectorDeEnsambladores(vectorDeEnsambladores);

        // Llamo a actualizar la interfaz
        interfaz.actualizarInterfaz();

    }

}
